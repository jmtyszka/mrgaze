from distutils.core import setup
setup ( name = 'geetee',
        version = '0.1',
        packages = ['geetee'],
      ) 
